﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class MajorMinorAss4
    {
        static void Main()
        {
            Console.WriteLine("Enter the age of person:");
            int person = Convert.ToInt32(Console.ReadLine());
            String result = person > 18 ? "you are eligible" : "you are not eligible";
            Console.WriteLine(result);
        }
    }
}
