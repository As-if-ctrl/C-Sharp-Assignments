﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class SearchElementAss3
    {
        static void Main()
        {

            int[][] arr = new int[2][];
            arr[0] = new int[3] { 10, 12, 54 };
            arr[1] = new int[4] { 45, 20, 65, 78 };

            Console.WriteLine("Enter search number:");
            int num = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < 2; i++)
            {
                foreach (int temp in arr[i])
                {
                    if (temp != num)
                    {
                        continue;

                    }
                    else
                    {
                        Console.WriteLine("Element is present {0}", temp);
                        break;
                    }
                }
            }
            Console.ReadLine();

        }
    }
}
