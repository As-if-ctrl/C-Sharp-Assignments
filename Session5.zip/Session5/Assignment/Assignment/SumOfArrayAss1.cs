﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class SumOfArrayAss1
    {
        static void Main()
        {
            Console.WriteLine("Enter the Size of Array");
            int size = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the elements of Array");
            int[] arr = new int[size];
            for (int i = 0; i < size; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());

            }
            int sum = 0;
            Console.WriteLine("Sum of Array:");
            for (int i = 0; i < arr.Length; i++)
            {
                sum = sum + arr[i];

            }
            Console.WriteLine(sum);
            Console.ReadLine();

        }
    }
}
