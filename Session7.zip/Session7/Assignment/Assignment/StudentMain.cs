﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class StudentMain
    {
        static void Main(string[] args)
        {
            StudentAss1cs s = new StudentAss1cs(101, "Asif", "Male", 8805560869);
            Console.WriteLine(s.display());
        }
    }
}
