﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    struct StudentAss1cs
    {
        int Roll_No;
        long Mobile_No;
        string Name, Gender;

        public StudentAss1cs(int Roll_No, string Name, string Gender, long Mobile_No)
        {
            this.Roll_No = Roll_No;
            this.Name = Name;
            this.Gender = Gender;
            this.Mobile_No = Mobile_No;
        }

        public string display()
        {
            return ($"Roll No={Roll_No} Name={Name} Gender={Gender} Mobile No={Mobile_No}");
        }
    }
}
