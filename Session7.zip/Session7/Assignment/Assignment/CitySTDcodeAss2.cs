﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class CitySTDcodeAss2
    {
        public enum city
        {
            Nagar = 0240, Pune = 0220, Mumbai = 0200
        }

        static void Main()
        {
            foreach (string city in Enum.GetNames(typeof(city)))
            {
                Console.WriteLine("Name of Citys = {0}", city);
            }
            foreach (int code in Enum.GetValues(typeof(city)))
            {
                Console.WriteLine("STD code of Citys = {0}", code);
            }
            Console.ReadLine();
        }
        
    }
}
