﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class OddnumberAss2
    {
        /// <summary>
        /// Using do while loop
        /// </summary>
        static void Main()
        {
            int i = 1;
            do
            {
                if (i % 2 != 0)
                {
                    Console.WriteLine(i);
                }
                i++;
            }
            while (i <= 50);
        }
    }
}
