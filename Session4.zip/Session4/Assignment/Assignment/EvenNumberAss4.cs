﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class EvenNumberAss4
    {
        /// <summary>
        /// Identify Even number in array
        /// </summary>
        static void Main()
        {
            Console.WriteLine("Enter the size of array:");
            int size = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the elements of arrays");
            int[] arr = new int[size];
            for (int i = 0; i < size; i++)
            {
                arr[i] = i + 1;
            }

            Console.WriteLine("Show the Even numbers in array:");
            foreach (int temp in arr)
            {
                if (temp % 2 == 0)
                {
                    Console.WriteLine(temp);
                }
            }
        }
    }
}
