﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class SimpleInterestAss4
    {
        public double PayableAmount(double rate, double amount, double time, out double Interest)
        {
            Interest = amount * rate * time / 100;
            double TotalAmount = amount + Interest;
            return TotalAmount;
        }

    }
}
