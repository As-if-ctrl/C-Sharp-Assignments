﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class GSTAss5
    {
        public string GST(double Amount, int gst = 1, string msg = "Total Amount Including GST:")
        {
            double TotalAmount = Amount * gst / 100;
            return ($"{msg} {TotalAmount}");
        }

        static void Main()
        {
            GSTAss5 g = new GSTAss5();

            Console.WriteLine("Enter the Amount :");
            double Amt1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the GST rate :");
            int gst = Convert.ToInt32(Console.ReadLine());


            Console.WriteLine($"{g.GST(Amt1, gst)}");
        }
    }
}
