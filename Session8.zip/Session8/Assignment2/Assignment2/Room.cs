﻿using System;


namespace Assignment2
{
    class Room
    {
        //Calling Room calss from RoomMain Class
        private int R_number;
        private int R_floor;
        private int R_capacity;
        private string R_type;
        private double R_price;
        private DateTime R_bookedTime;

        public Room()
        {
            Console.WriteLine("Invoke Default Constructor");
        }

        public Room(int R_number, int R_floor, int R_capacity, string R_type, double R_price, DateTime R_bookedTime)
        {
            this.R_number = R_number;
            this.R_floor = R_floor;
            this.R_capacity = R_capacity;
            this.R_type = R_type;
            this.R_price = R_price;
            this.R_bookedTime = R_bookedTime;
        }


        public override string ToString()
        {
            Console.WriteLine("\nShow Room Booked Details:\n");
            return ($"Room Number = {R_number} " +
                      $"\nFloor Number = {R_floor} " +
                      $"\nRoom Type = {R_type}" +
                      $"\nRoom Capacity = {R_capacity}" +
                      $"\nRoom Booked Time = {R_bookedTime.ToShortDateString()}" +
                      $"\nRoom Price = {R_price}");
        }
    }
}
