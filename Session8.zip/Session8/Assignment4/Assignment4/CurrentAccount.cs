﻿using System;

namespace Assignment4
{
    class CurrentAccount
    {
        double t_Amount;
        double amount;

        public void Deposit(double amount)
        {
            Console.WriteLine("Previous Balance = {0}", t_Amount);
            t_Amount = t_Amount + amount;

            Console.WriteLine("Deposite Amount = {0} \nTotal Balance = {1}", t_Amount, amount);
        }

        public void Withdraw(double amount)
        {
            if (t_Amount > amount)
            {
                Console.WriteLine("Previous Balance = {0}", t_Amount);
                t_Amount = t_Amount - amount;
                Console.WriteLine("Withdraw Amount = {0}", amount);
                Console.WriteLine("Remaining Balance = {0}", t_Amount);
            }
            else
            {
                Console.WriteLine("Insufficient Balance in Account = {0}", amount);
            }

            Console.ReadLine();
        }

        static void Main()
        {
            CurrentAccount ca = new CurrentAccount();

            //To pass some amount for deposite or withdrawa
            Console.WriteLine("Enter deposite amount ");
            double amt = Convert.ToDouble(Console.ReadLine());

            ca.Deposit(amt);

            Console.WriteLine("Enter withdraw amount ");
            double amt1 = Convert.ToDouble(Console.ReadLine());

            ca.Withdraw(amt1);
        }

    }
}
