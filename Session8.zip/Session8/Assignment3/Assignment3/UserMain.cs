﻿using System;
using System.Collections.Generic;

namespace Assignment3
{
    class UserMain
    {
        static void Main(string[] args)
        {
            //Calling default constructor
            User u = new User();
            

            List<User> list = new List<User>();
            int Choose;


            //Pass the user details from user
            do
            {
                Console.WriteLine("Enter User Id:");
                long id = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter User Name:");
                string name = Console.ReadLine();

                Console.WriteLine("Enter User Email Id:");
                string email = Console.ReadLine();
                bool flag = u.valid(list, email);

                Console.WriteLine("Enter User Date of Birth:");
                string DoB = Console.ReadLine();

                while (!flag)
                {
                    Console.WriteLine("Please try another email id . Email ID is already exist...... ");
                    email = Console.ReadLine();
                    flag = u.valid(list, email);
                }

                //calling parameterised constructor and set the value
                User u1 = new User(id, name, email, DoB);
                list.Add(u1);
                
                //Show the details of user
                Console.WriteLine($"\nDetails of User :\n {u1}");

                Console.WriteLine("If you want register again Enter \"1\" else Enter any Digit");
                Choose = Convert.ToInt32(Console.ReadLine());
            }

            while (Choose == 1);
            Console.ReadLine();
        }
    }
}
