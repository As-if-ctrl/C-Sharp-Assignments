﻿using System;


namespace Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            SuperComputer sc = new SuperComputer();
            Console.WriteLine(sc.BootUp());
            Console.WriteLine(sc.ShutDwon());

            Console.WriteLine("==========================================");

            MainfraimComputer mc = new MainfraimComputer();
            Console.WriteLine(mc.BootUp());
            Console.WriteLine(mc.ShutDwon());

            Console.WriteLine("===========================================");

            MicroComputer mic = new MicroComputer();
            Console.WriteLine(mic.BootUp());
            Console.WriteLine(mic.ShutDwon());
            Console.ReadLine();
        }
    }
}
